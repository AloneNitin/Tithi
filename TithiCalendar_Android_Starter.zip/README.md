# Tithi Calendar (Android starter)

A native Android calendar starter with Indian-region styling, month navigation, date selection, festival notes, Hindi/English UI toggle, and in-memory custom events.

## Current implementation
- Monthly grid with date selection and previous/next month navigation
- English/Hindi toggle for key calendar labels
- Static 2026 festival list (some dates marked approximate/tentative)
- Selected-day festival/event display
- Add a basic personal event (stored in memory only; not persistent yet)
- Panchang and sunrise/sunset placeholders clearly labeled as not integrated

## Not implemented yet
- Verified full Indian holiday dataset / annual refresh
- Accurate regional Panchang (requires location and reliable ephemeris source)
- Persistent event storage, Android notification/reminder scheduling
- Sunrise/sunset calculations
- App icon, splash, tests, release signing

## Build APK
1. Install Android Studio (stable) and Android SDK 35.
2. Open this project folder in Android Studio and let Gradle sync.
3. Run on emulator or phone to test.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

Or use terminal in project folder:
```bash
gradle assembleDebug
```
Requires a compatible JDK, Android SDK and Gradle installed/configured. The wrapper is not included in this starter ZIP.

## Accuracy notes
Festival dates are demo data and must be verified against official sources before public release. Panchang values are not calculated yet.
