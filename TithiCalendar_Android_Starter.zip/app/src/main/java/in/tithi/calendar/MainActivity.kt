package in.tithi.calendar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TithiApp() }
    }
}

private val saffron = Color(0xFFFF9933)
private val green = Color(0xFF138808)
private val cream = Color(0xFFFFF8E8)
private val teal = Color(0xFF00796B)
private val ink = Color(0xFF24312C)

private val festivalDates = mapOf(
    "2026-01-14" to "Makar Sankranti / Lohri",
    "2026-01-26" to "Republic Day",
    "2026-03-04" to "Holi",
    "2026-03-20" to "Eid al-Fitr (tentative)",
    "2026-04-14" to "Vaisakhi",
    "2026-08-15" to "Independence Day",
    "2026-08-26" to "Janmashtami",
    "2026-10-02" to "Gandhi Jayanti",
    "2026-10-20" to "Dussehra (approx.)",
    "2026-11-08" to "Diwali (approx.)",
    "2026-11-24" to "Guru Nanak Jayanti (approx.)",
    "2026-12-25" to "Christmas"
)

@Composable
fun TithiApp() {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var hindi by remember { mutableStateOf(false) }
    var customEvents by remember { mutableStateOf(mapOf<String, String>()) }
    var showAdd by remember { mutableStateOf(false) }
    var eventText by remember { mutableStateOf("") }
    val dateKey = selected.toString()
    val fest = festivalDates[dateKey]
    val event = customEvents[dateKey]

    MaterialTheme(colorScheme = lightColorScheme(primary = teal, secondary = saffron, background = cream)) {
        Surface(color = cream, modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("Tithi Calendar", style = MaterialTheme.typography.headlineMedium, color = teal, fontWeight = FontWeight.Bold)
                        Text(if (hindi) "भारतीय कैलेंडर" else "Indian calendar", color = green)
                    }
                    IconButton(onClick = { hindi = !hindi }) {
                        Icon(Icons.Default.Language, contentDescription = "Switch language", tint = teal)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, "Previous month") }
                            Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)), fontWeight = FontWeight.Bold, color = ink)
                            IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, "Next month") }
                        }
                        val weekdays = if (hindi) listOf("रवि","सोम","मंगल","बुध","गुरु","शुक्र","शनि") else listOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
                        Row(Modifier.fillMaxWidth()) {
                            weekdays.forEach { Text(it, modifier = Modifier.weight(1f), color = teal, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall) }
                        }
                        Spacer(Modifier.height(8.dp))
                        val firstOffset = month.atDay(1).dayOfWeek.value % 7
                        val days = month.lengthOfMonth()
                        val totalCells = ((firstOffset + days + 6) / 7) * 7
                        for (week in 0 until totalCells / 7) {
                            Row(Modifier.fillMaxWidth()) {
                                for (col in 0..6) {
                                    val dayNum = week * 7 + col - firstOffset + 1
                                    if (dayNum in 1..days) {
                                        val dayDate = month.atDay(dayNum)
                                        val isSelected = dayDate == selected
                                        val hasMark = festivalDates.containsKey(dayDate.toString()) || customEvents.containsKey(dayDate.toString())
                                        Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp)
                                            .background(if (isSelected) saffron else Color.Transparent, RoundedCornerShape(10.dp))
                                            .clickable { selected = dayDate }, contentAlignment = Alignment.Center) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(dayNum.toString(), color = if (isSelected) Color.White else ink, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                                if (hasMark) Box(Modifier.size(4.dp).background(if (isSelected) Color.White else green, RoundedCornerShape(50)))
                                            }
                                        }
                                    } else Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(selected.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")), color = teal, fontWeight = FontWeight.Bold)
                        Text(if (hindi) "आज का पंचांग" else "Panchang & day details", style = MaterialTheme.typography.titleMedium, color = ink)
                        Spacer(Modifier.height(8.dp))
                        Text(if (fest != null) "🎉 $fest" else if (hindi) "कोई प्रमुख त्योहार सूचीबद्ध नहीं" else "No major festival listed", color = saffron, fontWeight = FontWeight.SemiBold)
                        event?.let { Text("📝 $it", color = green) }
                        Spacer(Modifier.height(4.dp))
                        Text(if (hindi) "तिथि / नक्षत्र / योग: पंचांग डेटा अभी जोड़ा जाना बाकी है" else "Tithi / Nakshatra / Yoga: Panchang data not yet integrated", style = MaterialTheme.typography.bodySmall, color = ink)
                        Text(if (hindi) "सूर्योदय / सूर्यास्त: स्थान-आधारित डेटा अभी उपलब्ध नहीं" else "Sunrise / sunset: location-based data not yet available", style = MaterialTheme.typography.bodySmall, color = ink)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { showAdd = true }, colors = ButtonDefaults.buttonColors(containerColor = teal)) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (hindi) "कार्य / याद दिलाएं जोड़ें" else "Add event / reminder")
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(if (hindi) "सूचीबद्ध पर्व (2026)" else "Festival notes (2026)", color = green, fontWeight = FontWeight.Bold)
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(festivalDates.toList().sortedBy { it.first }) { (date, name) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(date, color = ink, style = MaterialTheme.typography.bodySmall)
                            Text(name, color = ink, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    if (showAdd) {
        AlertDialog(onDismissRequest = { showAdd = false }, title = { Text(if (hindi) "कार्य जोड़ें" else "Add event") },
            text = { OutlinedTextField(value = eventText, onValueChange = { eventText = it }, label = { Text("Event or reminder") }) },
            confirmButton = { TextButton(onClick = {
                if (eventText.isNotBlank()) customEvents = customEvents + (dateKey to eventText.trim())
                eventText = ""; showAdd = false
            }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } })
    }
}
