# Tithi Calendar Flutter Starter

A simple Flutter calendar app with:
- Monthly calendar grid and previous/next month navigation
- Select a date and jump back to today
- English/Hindi labels toggle
- Selected-date summary
- Android APK build using GitHub Actions

## Important Panchang note

This starter does **not** calculate real Hindu tithi, nakshatra, muhurat, sunrise/sunset, or festival dates. These depend on astronomical calculations and often on the observer's location and local time. The UI deliberately labels unavailable tithi information rather than inventing it. Add a verified Panchang API or a reliable astronomy calculation library before publishing as an accurate Panchang.

## Upload to GitHub

1. Create a new empty repository on GitHub, for example `tithi-calendar`.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Make sure `.github/workflows/android-apk.yml` is included. GitHub may hide `.github` folders in some mobile file pickers; check that it was uploaded.
4. Open the repository's **Actions** tab.
5. Select **Build Tithi Calendar APK** and press **Run workflow**, or push a commit to `main`/`master`.
6. When the run completes, open the workflow run and download the `tithi-calendar-apk` artifact.

## Build locally

Install Flutter and Android SDK, then run:

```bash
flutter pub get
flutter analyze
flutter run
flutter build apk --release
```

The workflow creates standard Android platform files with `flutter create` before building, so this ZIP stays compact and avoids committing generated Gradle wrapper/platform boilerplate.
