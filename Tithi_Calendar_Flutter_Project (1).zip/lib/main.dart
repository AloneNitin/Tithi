import 'package:flutter/material.dart';

void main() => runApp(const TithiCalendarApp());

class TithiCalendarApp extends StatelessWidget {
  const TithiCalendarApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8B3A24);
    return MaterialApp(
      title: 'Tithi Calendar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFFFF8F0),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      home: const CalendarHomePage(),
    );
  }
}

class CalendarHomePage extends StatefulWidget {
  const CalendarHomePage({super.key});

  @override
  State<CalendarHomePage> createState() => _CalendarHomePageState();
}

class _CalendarHomePageState extends State<CalendarHomePage> {
  DateTime _selectedDate = DateTime.now();
  DateTime _visibleMonth = DateTime(DateTime.now().year, DateTime.now().month);
  bool _hindi = false;

  static const List<String> _englishMonths = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  static const List<String> _hindiMonths = [
    'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
    'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'
  ];
  static const List<String> _weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  static const List<String> _hindiWeekdays = ['सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'रवि'];

  String get _monthTitle =>
      '${_hindi ? _hindiMonths[_visibleMonth.month - 1] : _englishMonths[_visibleMonth.month - 1]} ${_visibleMonth.year}';

  void _changeMonth(int offset) {
    setState(() {
      _visibleMonth = DateTime(_visibleMonth.year, _visibleMonth.month + offset);
      final lastDay = DateTime(_visibleMonth.year, _visibleMonth.month + 1, 0).day;
      if (_selectedDate.year != _visibleMonth.year ||
          _selectedDate.month != _visibleMonth.month) {
        _selectedDate = DateTime(
          _visibleMonth.year,
          _visibleMonth.month,
          _selectedDate.day.clamp(1, lastDay),
        );
      }
    });
  }

  void _selectDate(DateTime date) => setState(() => _selectedDate = date);

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final selectedIsToday = _sameDay(today, _selectedDate);
    return Scaffold(
      appBar: AppBar(
        title: Text(_hindi ? 'तिथि कैलेंडर' : 'Tithi Calendar'),
        actions: [
          TextButton.icon(
            onPressed: () => setState(() => _hindi = !_hindi),
            icon: const Icon(Icons.translate),
            label: Text(_hindi ? 'English' : 'हिंदी'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            _TodayCard(
              isHindi: _hindi,
              date: today,
              selectedDate: _selectedDate,
              selectedIsToday: selectedIsToday,
              onToday: () {
                setState(() {
                  _selectedDate = today;
                  _visibleMonth = DateTime(today.year, today.month);
                });
              },
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 0,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          tooltip: 'Previous month',
                          onPressed: () => _changeMonth(-1),
                          icon: const Icon(Icons.chevron_left),
                        ),
                        Expanded(
                          child: Text(
                            _monthTitle,
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Next month',
                          onPressed: () => _changeMonth(1),
                          icon: const Icon(Icons.chevron_right),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: List.generate(7, (index) {
                        return Expanded(
                          child: Center(
                            child: Text(
                              _hindi ? _hindiWeekdays[index] : _weekdays[index],
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 8),
                    _buildMonthGrid(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            _SelectedDateCard(date: _selectedDate, isHindi: _hindi),
            const SizedBox(height: 16),
            _PanchangNotice(isHindi: _hindi),
          ],
        ),
      ),
    );
  }

  Widget _buildMonthGrid() {
    final firstWeekday = DateTime(_visibleMonth.year, _visibleMonth.month, 1).weekday;
    final daysInMonth =
        DateTime(_visibleMonth.year, _visibleMonth.month + 1, 0).day;
    final cellCount = ((firstWeekday - 1 + daysInMonth + 6) ~/ 7) * 7;
    final today = DateTime.now();

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: cellCount,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        mainAxisSpacing: 4,
        crossAxisSpacing: 4,
        childAspectRatio: 0.82,
      ),
      itemBuilder: (context, index) {
        final dayNumber = index - (firstWeekday - 1) + 1;
        if (dayNumber < 1 || dayNumber > daysInMonth) {
          return const SizedBox.shrink();
        }
        final date = DateTime(_visibleMonth.year, _visibleMonth.month, dayNumber);
        final isSelected = _sameDay(date, _selectedDate);
        final isToday = _sameDay(date, today);
        return Semantics(
          button: true,
          selected: isSelected,
          label: '${_englishMonths[date.month - 1]} ${date.day}, ${date.year}',
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => _selectDate(date),
            child: Container(
              decoration: BoxDecoration(
                color: isSelected
                    ? Theme.of(context).colorScheme.primary
                    : isToday
                        ? Theme.of(context).colorScheme.primaryContainer
                        : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: isToday && !isSelected
                    ? Border.all(color: Theme.of(context).colorScheme.primary)
                    : null,
              ),
              alignment: Alignment.center,
              child: Text(
                '$dayNumber',
                style: TextStyle(
                  fontWeight: isSelected || isToday ? FontWeight.bold : FontWeight.normal,
                  color: isSelected
                      ? Colors.white
                      : Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _TodayCard extends StatelessWidget {
  const _TodayCard({
    required this.isHindi,
    required this.date,
    required this.selectedDate,
    required this.selectedIsToday,
    required this.onToday,
  });

  final bool isHindi;
  final DateTime date;
  final DateTime selectedDate;
  final bool selectedIsToday;
  final VoidCallback onToday;

  @override
  Widget build(BuildContext context) {
    final weekday = isHindi
        ? const ['सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार', 'रविवार'][date.weekday - 1]
        : const ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][date.weekday - 1];
    return Card(
      elevation: 0,
      color: const Color(0xFFFFE8D5),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              width: 58,
              height: 64,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('${date.day}', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                  Text(isHindi ? 'आज' : 'TODAY', style: const TextStyle(fontSize: 10, letterSpacing: 0.8)),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(isHindi ? 'आज का दिन' : 'Your calendar', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text('$weekday, ${date.month}/${date.day}/${date.year}'),
                  if (!selectedIsToday)
                    Text(
                      isHindi
                          ? 'चयनित तारीख: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'
                          : 'Selected: ${selectedDate.month}/${selectedDate.day}/${selectedDate.year}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                ],
              ),
            ),
            IconButton(onPressed: onToday, tooltip: 'Go to today', icon: const Icon(Icons.today)),
          ],
        ),
      ),
    );
  }
}

class _SelectedDateCard extends StatelessWidget {
  const _SelectedDateCard({required this.date, required this.isHindi});
  final DateTime date;
  final bool isHindi;

  @override
  Widget build(BuildContext context) {
    final weekday = isHindi
        ? const ['सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार', 'रविवार'][date.weekday - 1]
        : const ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][date.weekday - 1];
    final month = isHindi
        ? const ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'][date.month - 1]
        : const ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][date.month - 1];
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(isHindi ? 'चयनित तारीख' : 'Selected date', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('$weekday, ${date.day} $month ${date.year}', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            const Divider(),
            const SizedBox(height: 4),
            Row(
              children: [
                const Icon(Icons.brightness_5_outlined, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(isHindi ? 'तिथि की जानकारी' : 'Tithi information')),
                const Chip(label: Text('—')),
              ],
            ),
            Text(
              isHindi
                  ? 'सटीक तिथि, नक्षत्र और मुहूर्त के लिए स्थानीय पंचांग डेटा आवश्यक है।'
                  : 'Accurate tithi, nakshatra, and muhurat require a location-aware Panchang data source.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _PanchangNotice extends StatelessWidget {
  const _PanchangNotice({required this.isHindi});
  final bool isHindi;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: const Color(0xFFE8F2E5),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.info_outline, color: Color(0xFF315D38)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isHindi ? 'पंचांग के बारे में' : 'About Panchang data',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF244B2B)),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isHindi
                        ? 'यह संस्करण कैलेंडर और तारीख चुनने की सुविधा देता है। सही तिथि/नक्षत्र, सूर्योदय और त्योहारों के लिए सत्यापित पंचांग API या गणना लाइब्रेरी जोड़ें।'
                        : 'This starter includes a working date calendar and Hindi/English labels. For reliable tithi, nakshatra, sunrise times, and festival dates, connect a verified Panchang API or astronomy library.',
                    style: const TextStyle(color: Color(0xFF244B2B)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

bool _sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;
